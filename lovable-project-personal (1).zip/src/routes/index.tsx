import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { CustomCursor } from "@/components/CustomCursor";
import { NodeField } from "@/components/NodeField";
import { TagCloud3D } from "@/components/TagCloud3D";
import { BentoProjects } from "@/components/BentoProjects";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AKSHAY.DEV — Full-Stack Developer, Nagpur" },
      {
        name: "description",
        content:
          "Akshay Gedam — Node.js architect, RBAC systems builder and enterprise workflow engineer from Nagpur. Selected work: Turo, Solarpix, Sanvid.",
      },
      { property: "og:title", content: "AKSHAY.DEV — Full-Stack Developer" },
      {
        property: "og:description",
        content: "Node.js architect & enterprise workflow engineer. Brutalist portfolio.",
      },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700;900&display=swap",
      },
    ],
  }),
  component: Index,
});

const marqueeItems = [
  "NODE.JS ARCHITECT",
  "RBAC SYSTEMS",
  "ENTERPRISE WORKFLOWS",
  "POSTGRES · REDIS · MONGO",
  "BASED IN NAGPUR",
  "OPEN FOR CONTRACTS",
];

function Index() {
  const root = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const ctx = gsap.context(() => {
      gsap.from("[data-hero-line]", {
        yPercent: 110,
        duration: 1.1,
        ease: "power4.out",
        stagger: 0.08,
        delay: 0.1,
      });
      gsap.from("[data-hero-meta]", {
        opacity: 0,
        y: 20,
        duration: 0.8,
        ease: "power3.out",
        delay: 0.8,
      });
      gsap.utils.toArray<HTMLElement>("[data-slide]").forEach((el) => {
        gsap.from(el, {
          opacity: 0,
          y: 80,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: { trigger: el, start: "top 85%" },
        });
      });
      gsap.utils.toArray<HTMLElement>("[data-section-label]").forEach((el) => {
        gsap.from(el, {
          xPercent: -30,
          opacity: 0,
          duration: 0.9,
          ease: "power3.out",
          scrollTrigger: { trigger: el, start: "top 90%" },
        });
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <div ref={root} className="min-h-screen text-foreground overflow-x-hidden">
      <CustomCursor />

      {/* NAV */}
      <header className="fixed top-0 inset-x-0 z-50 flex justify-between items-center px-6 md:px-10 py-5">
        <a href="#top" className="font-black text-lg tracking-tight">A.G ⏶</a>
        <nav className="hidden md:flex gap-7 text-xs font-black uppercase tracking-widest">
          <a href="#work" className="hover:text-[var(--orange)]">Work</a>
          <a href="#skills" className="hover:text-[var(--orange)]">Stack</a>
          <a href="#contact" className="hover:text-[var(--orange)]">Contact</a>
        </nav>
        <a href="#contact" className="hidden md:inline-block bg-[var(--orange)] text-white px-4 py-2 brutal-border brutal-shadow font-black text-xs uppercase tracking-widest">
          Hire Me →
        </a>
      </header>

      {/* HERO */}
      <section id="top" className="relative h-screen min-h-[680px] flex flex-col justify-center overflow-hidden">
        <NodeField />
        <div className="relative px-4 md:px-8 z-10">
          <h1 className="font-black tracking-[-0.06em] leading-[0.82] text-[22vw] md:text-[18vw] lg:text-[15rem] text-center select-none">
            <span className="block overflow-hidden">
              <span data-hero-line className="block">AKSHAY</span>
            </span>
            <span className="block overflow-hidden">
              <span data-hero-line className="block">
                <span className="text-[var(--orange)]">.</span>DEV
              </span>
            </span>
          </h1>
        </div>
        <div data-hero-meta className="absolute bottom-10 inset-x-0 px-6 md:px-10 flex justify-between items-end z-10">
          <div className="max-w-xs text-sm font-bold leading-tight">
            FULL-STACK DEV · NAGPUR<br/>
            <span className="font-medium opacity-70">Building enterprise systems that don't fall over at 3am.</span>
          </div>
          <div className="text-xs font-black uppercase tracking-widest flex items-center gap-2">
            <span className="w-2 h-2 bg-[var(--orange)] rounded-full animate-pulse" />
            Scroll
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <section className="border-y-2 border-black py-5 overflow-hidden bg-black text-[var(--background)]">
        <div className="flex whitespace-nowrap animate-marquee">
          {[...marqueeItems, ...marqueeItems, ...marqueeItems].map((t, i) => (
            <span key={i} className="text-3xl md:text-5xl font-black px-8 flex items-center gap-8">
              {t}
              <span className="text-[var(--orange)]">✦</span>
            </span>
          ))}
        </div>
      </section>

      {/* ABOUT / INTRO */}
      <section className="px-6 md:px-10 py-28 md:py-40 max-w-6xl mx-auto">
        <div data-section-label className="text-xs font-black uppercase tracking-widest mb-6 flex items-center gap-3">
          <span className="w-8 h-[2px] bg-black" /> 001 / INTRO
        </div>
        <h2 data-slide className="text-5xl md:text-7xl lg:text-8xl font-black leading-[0.9] tracking-tight">
          I architect <span className="bg-[var(--green)] px-2">backends</span>,<br/>
          design <span className="bg-[var(--blue)] text-white px-2">permission systems</span>,<br/>
          and ship <span className="bg-[var(--orange)] text-white px-2">workflows</span><br/>
          enterprises actually trust.
        </h2>
      </section>

      {/* WORK */}
      <section id="work" className="px-6 md:px-10 py-20 md:py-28 max-w-7xl mx-auto">
        <div data-section-label className="text-xs font-black uppercase tracking-widest mb-6 flex items-center gap-3">
          <span className="w-8 h-[2px] bg-black" /> 002 / SELECTED WORK
        </div>
        <h2 data-slide className="text-5xl md:text-7xl font-black mb-12 tracking-tight">
          Three systems.<br/>Three production scars.
        </h2>
        <div data-slide>
          <BentoProjects />
        </div>
      </section>

      {/* SKILLS */}
      <section id="skills" className="px-6 md:px-10 py-20 md:py-28 max-w-7xl mx-auto">
        <div data-section-label className="text-xs font-black uppercase tracking-widest mb-6 flex items-center gap-3">
          <span className="w-8 h-[2px] bg-black" /> 003 / STACK
        </div>
        <div className="grid md:grid-cols-[1fr_1.4fr] gap-10 items-start">
          <div>
            <h2 data-slide className="text-5xl md:text-7xl font-black mb-6 tracking-tight">
              Tools I reach<br/>for daily.
            </h2>
            <p data-slide className="text-base font-medium max-w-sm opacity-80">
              Hover or drag the cloud. Click anything for what it actually does in my work — no resume-keyword theater.
            </p>
          </div>
          <div data-slide>
            <TagCloud3D />
          </div>
        </div>
      </section>

      {/* TIMELINE */}
      <section className="px-6 md:px-10 py-20 md:py-28 max-w-6xl mx-auto">
        <div data-section-label className="text-xs font-black uppercase tracking-widest mb-6 flex items-center gap-3">
          <span className="w-8 h-[2px] bg-black" /> 004 / JOURNEY
        </div>
        <h2 data-slide className="text-5xl md:text-7xl font-black mb-12 tracking-tight">
          The receipts.
        </h2>
        <div className="space-y-0">
          {[
            { y: "2024 — NOW", t: "Senior Backend Architect", w: "Independent · Enterprise contracts", c: "var(--orange)" },
            { y: "2022 — 2024", t: "Lead Full-Stack Engineer", w: "Sanvid · Workflow platform", c: "var(--green)" },
            { y: "2020 — 2022", t: "Backend Engineer", w: "Solarpix · IoT + RBAC dashboards", c: "var(--blue)" },
            { y: "2019 — 2020", t: "B.E. Computer Science", w: "RTM Nagpur University", c: "#0a0a0a" },
          ].map((r) => (
            <div data-slide key={r.t} className="grid grid-cols-[120px_1fr_auto] md:grid-cols-[180px_1fr_auto] gap-4 md:gap-8 py-6 border-t-2 border-black items-center">
              <div className="text-xs md:text-sm font-black uppercase tracking-widest">{r.y}</div>
              <div>
                <div className="text-2xl md:text-4xl font-black tracking-tight">{r.t}</div>
                <div className="text-sm font-medium opacity-70 mt-1">{r.w}</div>
              </div>
              <div className="w-6 h-6 md:w-8 md:h-8 brutal-border" style={{ background: r.c }} />
            </div>
          ))}
          <div className="border-t-2 border-black" />
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="px-6 md:px-10 py-24 md:py-40 bg-black text-[var(--background)] relative overflow-hidden">
        <div data-section-label className="text-xs font-black uppercase tracking-widest mb-6 flex items-center gap-3 text-[var(--orange)]">
          <span className="w-8 h-[2px] bg-[var(--orange)]" /> 005 / CONTACT
        </div>
        <h2 data-slide className="text-[14vw] md:text-[10vw] font-black leading-[0.85] tracking-[-0.04em] mb-10">
          Let's Build<br/>
          <span className="text-[var(--orange)]">Enterprise</span><br/>
          Systems<br/>
          Together.
        </h2>
        <div data-slide className="flex flex-col md:flex-row md:items-end justify-between gap-8 max-w-6xl">
          <a
            href="mailto:akshay@akshay.dev"
            className="inline-block text-3xl md:text-5xl font-black underline decoration-[var(--orange)] decoration-[6px] underline-offset-8 hover:text-[var(--orange)] transition-colors break-all"
          >
            akshay@akshay.dev →
          </a>
          <div className="flex flex-wrap gap-3">
            {[
              { l: "GITHUB", h: "https://github.com" },
              { l: "LINKEDIN", h: "https://linkedin.com" },
              { l: "X / TWITTER", h: "https://twitter.com" },
            ].map((s) => (
              <a key={s.l} href={s.h} className="bg-[var(--orange)] text-black px-5 py-3 font-black text-xs uppercase tracking-widest brutal-border" style={{ borderColor: "#fff" }}>
                {s.l} ↗
              </a>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t-2 border-black px-6 md:px-10 py-6 flex flex-col md:flex-row justify-between items-center gap-3 text-xs font-black uppercase tracking-widest">
        <div>© {new Date().getFullYear()} AKSHAY GEDAM · NAGPUR, IN</div>
        <div>BUILT WITH REACT · THREE.JS · GSAP</div>
      </footer>
    </div>
  );
}
