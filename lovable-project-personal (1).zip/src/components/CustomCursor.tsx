import { useEffect, useRef } from "react";

export function CustomCursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let mx = window.innerWidth / 2;
    let my = window.innerHeight / 2;
    let dx = mx, dy = my;
    let rx = mx, ry = my;
    let raf = 0;

    const onMove = (e: MouseEvent) => { mx = e.clientX; my = e.clientY; };
    const onDown = () => ring.current?.classList.add("scale-75");
    const onUp = () => ring.current?.classList.remove("scale-75");

    const hoverables = "a, button, [data-hover]";
    const onOver = (e: MouseEvent) => {
      if ((e.target as HTMLElement).closest(hoverables)) {
        ring.current?.classList.add("scale-[2.2]");
      }
    };
    const onOut = (e: MouseEvent) => {
      if ((e.target as HTMLElement).closest(hoverables)) {
        ring.current?.classList.remove("scale-[2.2]");
      }
    };

    const tick = () => {
      dx += (mx - dx) * 0.55;
      dy += (my - dy) * 0.55;
      rx += (mx - rx) * 0.18;
      ry += (my - ry) * 0.18;
      if (dot.current) dot.current.style.transform = `translate(${dx - 4}px, ${dy - 4}px)`;
      if (ring.current) ring.current.style.transform = `translate(${rx - 18}px, ${ry - 18}px) ${ring.current.style.transform.includes("scale") ? "" : ""}`;
      raf = requestAnimationFrame(tick);
    };

    window.addEventListener("mousemove", onMove);
    window.addEventListener("mousedown", onDown);
    window.addEventListener("mouseup", onUp);
    window.addEventListener("mouseover", onOver);
    window.addEventListener("mouseout", onOut);
    raf = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mousedown", onDown);
      window.removeEventListener("mouseup", onUp);
      window.removeEventListener("mouseover", onOver);
      window.removeEventListener("mouseout", onOut);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <>
      <div
        ref={dot}
        className="fixed top-0 left-0 w-2 h-2 rounded-full bg-[var(--orange)] pointer-events-none z-[9999] mix-blend-difference"
      />
      <div
        ref={ring}
        className="fixed top-0 left-0 w-9 h-9 rounded-full border-2 border-black pointer-events-none z-[9998] transition-transform duration-200"
      />
    </>
  );
}
