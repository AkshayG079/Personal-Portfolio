import { ArchDiagram } from "./ArchDiagram";

const projects = [
  {
    name: "Turo",
    tag: "Peer-to-peer car sharing platform",
    desc: "Engineered booking, payments and fleet ops microservices handling thousands of concurrent reservations. Implemented Redis-backed availability cache cutting search latency 4x.",
    stack: ["Node.js", "NestJS", "Postgres", "Redis", "Stripe"],
    arch: [
      [{ label: "Next.js Web", color: "cyan" as const }, { label: "Mobile App", color: "cyan" as const }],
      [{ label: "API Gateway", color: "purple" as const }],
      [{ label: "Booking Svc", color: "purple" as const }, { label: "Payments Svc", color: "purple" as const }, { label: "Fleet Svc", color: "purple" as const }],
      [{ label: "Postgres", color: "amber" as const }, { label: "Redis Cache", color: "amber" as const }],
    ],
  },
  {
    name: "Solarpix",
    tag: "Solar asset monitoring suite",
    desc: "Built real-time telemetry pipeline ingesting inverter data from 12k+ panels. RBAC dashboards for installers, owners and field techs with row-level isolation.",
    stack: ["Node.js", "MQTT", "TimescaleDB", "React", "RBAC"],
    arch: [
      [{ label: "Inverters / IoT", color: "amber" as const }],
      [{ label: "MQTT Broker", color: "purple" as const }, { label: "Ingest Worker", color: "purple" as const }],
      [{ label: "Timescale DB", color: "amber" as const }],
      [{ label: "RBAC API", color: "purple" as const }, { label: "React Dashboard", color: "cyan" as const }],
    ],
  },
  {
    name: "Sanvid",
    tag: "Enterprise workflow & approvals",
    desc: "Designed a configurable workflow engine with dynamic approval chains, audit trails and SLA escalation. Powers HR, procurement and finance pipelines for mid-market clients.",
    stack: ["NestJS", "Postgres", "BullMQ", "Next.js"],
    arch: [
      [{ label: "Next.js Portal", color: "cyan" as const }],
      [{ label: "Workflow Engine", color: "purple" as const }, { label: "RBAC Service", color: "purple" as const }],
      [{ label: "BullMQ Queue", color: "purple" as const }],
      [{ label: "Postgres", color: "amber" as const }, { label: "Audit Store", color: "amber" as const }],
    ],
  },
];

export function Projects() {
  return (
    <div className="grid gap-8 md:gap-10">
      {projects.map((p) => (
        <article key={p.name} className="glass-card rounded-2xl p-6 md:p-8 grid md:grid-cols-[1fr_1.2fr] gap-8 items-start hover:border-[var(--purple)]/40 transition-colors">
          <div>
            <ArchDiagram boxes={p.arch} />
          </div>
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="font-mono text-xs text-[var(--cyan)]">// project</span>
            </div>
            <h3 className="text-2xl md:text-3xl font-mono text-glow-purple mb-1">{p.name}</h3>
            <p className="text-sm text-muted-foreground mb-4 font-mono">{p.tag}</p>
            <p className="text-foreground/90 leading-relaxed mb-5">{p.desc}</p>
            <div className="flex flex-wrap gap-2">
              {p.stack.map((s) => (
                <span
                  key={s}
                  className="px-2.5 py-1 rounded-md font-mono text-xs border border-border/80 bg-background/50 text-muted-foreground"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}
