import { useState } from "react";

type Project = {
  name: string;
  tag: string;
  desc: string;
  stack: string[];
  color: string;
  textOn: string;
  span: string;
  mock: "turo" | "solar" | "sanvid";
};

const projects: Project[] = [
  {
    name: "Turo",
    tag: "Peer-to-peer car sharing",
    desc: "Booking, payments and fleet ops microservices handling thousands of concurrent reservations. Redis-backed availability cache cut search latency 4x.",
    stack: ["Node.js", "NestJS", "Postgres", "Redis", "Stripe"],
    color: "#2ecc71",
    textOn: "#0a0a0a",
    span: "md:col-span-2 md:row-span-2",
    mock: "turo",
  },
  {
    name: "Solarpix",
    tag: "Solar asset monitoring",
    desc: "Real-time telemetry from 12k+ panels. RBAC dashboards for installers, owners and field techs with row-level isolation.",
    stack: ["MQTT", "TimescaleDB", "React", "RBAC"],
    color: "#2a7fff",
    textOn: "#ffffff",
    span: "md:col-span-2",
    mock: "solar",
  },
  {
    name: "Sanvid",
    tag: "Workflow & approvals engine",
    desc: "Configurable workflow engine with dynamic approval chains, audit trails and SLA escalation. Powers HR, procurement and finance pipelines.",
    stack: ["NestJS", "Postgres", "BullMQ", "Next.js"],
    color: "#ff6b00",
    textOn: "#0a0a0a",
    span: "md:col-span-2",
    mock: "sanvid",
  },
];

function MockUI({ kind }: { kind: Project["mock"] }) {
  if (kind === "turo") {
    return (
      <div className="bg-white brutal-border p-4 w-full h-full text-black">
        <div className="flex items-center justify-between mb-3">
          <div className="text-xs font-black">TURO · FLEET</div>
          <div className="text-[10px] font-bold bg-[#2ecc71] px-2 py-0.5">LIVE</div>
        </div>
        <div className="grid grid-cols-3 gap-2 mb-3">
          {[1,2,3].map(i => (
            <div key={i} className="brutal-border p-2">
              <div className="h-12 bg-[#2ecc71]/30 mb-1" />
              <div className="text-[9px] font-bold">#{i*1043}</div>
              <div className="text-[8px]">$84/day</div>
            </div>
          ))}
        </div>
        <div className="text-[10px] font-bold mb-1">RESERVATIONS</div>
        <div className="space-y-1">
          {["M. Patel · LAX → SFO","R. Hsu · NYC weekend","D. Ortiz · Austin pickup"].map(r => (
            <div key={r} className="text-[9px] border-l-4 border-[#2ecc71] pl-2">{r}</div>
          ))}
        </div>
      </div>
    );
  }
  if (kind === "solar") {
    return (
      <div className="bg-[#0a0a0a] brutal-border p-4 w-full h-full text-white">
        <div className="flex items-center justify-between mb-3">
          <div className="text-xs font-black">SOLARPIX · GRID</div>
          <div className="text-[10px] font-bold bg-[#2a7fff] px-2 py-0.5">12,481 ON</div>
        </div>
        <div className="grid grid-cols-12 gap-0.5 mb-3">
          {Array.from({length: 60}).map((_,i) => (
            <div key={i} className="aspect-square" style={{background: i%7===0 ? "#ff6b00" : "#2a7fff", opacity: 0.4 + Math.random()*0.6}} />
          ))}
        </div>
        <div className="text-[10px] font-bold text-[#2a7fff] mb-1">YIELD · 24H</div>
        <div className="flex items-end gap-0.5 h-10">
          {Array.from({length: 24}).map((_,i) => (
            <div key={i} className="flex-1 bg-[#2a7fff]" style={{height: `${30 + Math.sin(i/2)*40 + 30}%`}} />
          ))}
        </div>
      </div>
    );
  }
  return (
    <div className="bg-white brutal-border p-4 w-full h-full text-black">
      <div className="flex items-center justify-between mb-3">
        <div className="text-xs font-black">SANVID · APPROVALS</div>
        <div className="text-[10px] font-bold bg-[#ff6b00] text-white px-2 py-0.5">7 PENDING</div>
      </div>
      <div className="space-y-2">
        {[
          {t:"PR-2049 Laptops × 12", s:"Finance", st:"#ff6b00"},
          {t:"HR-118 New hire · Eng", s:"VP Eng", st:"#2ecc71"},
          {t:"PR-2051 AWS reserved", s:"CTO", st:"#0a0a0a"},
        ].map(r => (
          <div key={r.t} className="brutal-border p-2 flex justify-between items-center">
            <div>
              <div className="text-[10px] font-black">{r.t}</div>
              <div className="text-[9px]">awaiting · {r.s}</div>
            </div>
            <div className="w-3 h-3" style={{background: r.st}} />
          </div>
        ))}
      </div>
      <div className="mt-3 text-[9px] flex gap-2">
        <span className="bg-black text-white px-2 py-0.5 font-bold">SLA 4h</span>
        <span className="border-2 border-black px-2 py-0.5 font-bold">AUDIT ✓</span>
      </div>
    </div>
  );
}

export function BentoProjects() {
  const [hover, setHover] = useState<string | null>(null);
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 md:auto-rows-[260px] gap-5">
      {projects.map((p) => (
        <article
          key={p.name}
          data-hover
          onMouseEnter={() => setHover(p.name)}
          onMouseLeave={() => setHover(null)}
          className={`relative overflow-hidden brutal-border brutal-shadow p-6 md:p-8 transition-transform hover:-translate-x-1 hover:-translate-y-1 ${p.span}`}
          style={{ background: p.color, color: p.textOn }}
        >
          <div className="flex flex-col h-full justify-between relative z-10">
            <div>
              <div className="text-[10px] font-black uppercase tracking-widest mb-2 opacity-70">{p.tag}</div>
              <h3 className="text-4xl md:text-6xl font-black leading-none mb-3">{p.name}</h3>
              <p className="text-sm md:text-base font-medium max-w-md leading-snug">{p.desc}</p>
            </div>
            <div className="flex flex-wrap gap-2 mt-4">
              {p.stack.map(s => (
                <span key={s} className="text-[10px] font-black uppercase tracking-wider border-2 px-2 py-0.5"
                      style={{ borderColor: p.textOn }}>
                  {s}
                </span>
              ))}
            </div>
          </div>

          <div
            className={`absolute top-4 right-4 w-[58%] h-[78%] transition-all duration-500 z-20 ${
              hover === p.name ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"
            }`}
          >
            <div className="w-full h-full brutal-shadow">
              <MockUI kind={p.mock} />
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}
